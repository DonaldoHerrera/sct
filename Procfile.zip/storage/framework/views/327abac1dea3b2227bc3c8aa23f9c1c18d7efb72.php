<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(asset('empresas')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('empresas.form',['titleform'=>'Agregar Empresa'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\empresasSST\resources\views/empresas/create.blade.php ENDPATH**/ ?>