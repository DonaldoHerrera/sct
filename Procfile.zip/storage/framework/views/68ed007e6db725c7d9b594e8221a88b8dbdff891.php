<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/plugins/table/datatable/datatables.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/assets/css/forms/theme-checkbox-radio.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/plugins/table/datatable/dt-global_style.css')); ?>">
<?php /**PATH D:\work\empresasSST\resources\views/layouts/datatables/datatables_css.blade.php ENDPATH**/ ?>