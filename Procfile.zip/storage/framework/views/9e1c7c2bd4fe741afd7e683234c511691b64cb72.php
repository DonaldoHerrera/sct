<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/plugins/table/datatable/datatables.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/assets/css/forms/theme-checkbox-radio.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/plugins/table/datatable/dt-global_style.css')); ?>">
<?php /**PATH C:\Users\donal_atrhuea\OneDrive\Escritorio\empresasct\resources\views/layouts/datatables/datatables_css.blade.php ENDPATH**/ ?>