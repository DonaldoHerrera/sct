

<?php $__env->startSection('content'); ?>
<div class="row layout-top-spacing">
   <div class="card component-card_4">
      <div class="card-body">
         <div class="user-profile">
            <img src="<?php echo e(asset('empresas.png')); ?>" class="" width="100%" alt="...">
         </div>
         <div class="user-info">
            <h5 class="card-user_name">Luke Ivory</h5>
            <p class="card-user_occupation">EMPRESAS</p>
            <div class="card-star_rating">
               <span class="badge badge-primary"><?php echo e($empresas); ?> Empresa(s) registradas</span>
            </div>
            <p class="card-text"> Resumen de las empresas registradas en nuestro sistema SCT</p>
            <a href="<?php echo e(asset('empresas/create')); ?>" class="btn btn-outline-primary">Agregar empresa</a>
         </div>
      </div>
   </div>
   <div class="card component-card_4">
      <div class="card-body">
         <div class="user-profile">
            <img src="<?php echo e(asset('avatars/persona.png')); ?>" class="" width="100%" alt="...">
         </div>
         <div class="user-info">
            <h5 class="card-user_name">Luke Ivory</h5>
            <p class="card-user_occupation">USUARIOS</p>
            <div class="card-star_rating">
               <span class="badge badge-primary"><?php echo e($users); ?> Usuario(s) registrados</span>
            </div>
            <p class="card-text"> Resumen de los usuarios registrados en nuestra sistema SCT </p>
            <a href="<?php echo e(asset('usuarios/create')); ?>" class="btn btn-outline-primary">Agregar usuario</a>
         </div>
      </div>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\empresasSST\resources\views/resumen.blade.php ENDPATH**/ ?>