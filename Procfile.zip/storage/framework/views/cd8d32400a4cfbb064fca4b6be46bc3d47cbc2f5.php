
<?php $__env->startSection('datatables-css'); ?>
<?php echo $__env->make('layouts.datatables.datatables_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row layout-top-spacing" id="cancel-row">
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <div class="d-flex justify-content-start">
                <h3>LISTADO DE USUARIOS</h3>
            </div>
            <div class="d-flex justify-content-end">
                <a href="<?php echo e(asset('/usuarios/create')); ?>" type="button" class="btn btn-outline-primary">Agregar Usuario</a>
            </div>
            <div class="table-responsive mb-4 mt-4">
                <table id="zero-config" class="table table-hover" style="width:100%">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Correo Electrónico</th>
                            <th>Rol</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="d-flex">
                                    <div class="usr-img-frame mr-2 rounded-circle">
                                        <img alt="avatar" class="img-fluid rounded-circle" style="width:30px; height:30px;" src="<?php echo e(asset($user->avatar)); ?>">
                                    </div>
                                    <p class="align-self-center mb-0 admin-name"> <?php echo e($user->name); ?> </p>
                                </div>
                            </td>
                            <td><?php echo e($user->apellido); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td class="text-uppercase">
                                <span class=" badge <?php echo e($user->rol == 'admin' ? 'badge-success' : 'badge-danger'); ?>"><?php echo e($user->rol); ?></span>
                            </td>
                            <td>
                                <a href="<?php echo e(asset('/usuarios/'.$user->id)); ?>" class="btn-sm btn btn-outline-primary">Detalle</a>
                                <form action="<?php echo e(asset('usuarios/'.$user->id)); ?>" style="display:inline-block;" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Correo Electrónico</th>
                            <th>Fecha Registro</th>
                            <th>Acciones</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('datatables-js'); ?>
<?php echo $__env->make('layouts.datatables.datatables_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\empresasSST\resources\views/usuarios/index.blade.php ENDPATH**/ ?>