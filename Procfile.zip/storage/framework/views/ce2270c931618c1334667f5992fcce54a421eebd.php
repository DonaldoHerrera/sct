<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(asset('empresas/'.$empresa->id)); ?>" enctype="multipart/form-data" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <?php echo $__env->make('empresas.form',['titleform'=>'Actualizar empresa'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\empresasSST\resources\views/empresas/edit.blade.php ENDPATH**/ ?>