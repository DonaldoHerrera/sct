
<?php $__env->startSection('content'); ?>
    <div class="row layout-spacing">
        <!-- Content -->
        <div class="col-xl-3 col-lg-6 col-md-7 col-sm-12 layout-top-spacing">
            <div class="user-profile layout-spacing">
                <div class="widget-content widget-content-area">
                    <div class="d-flex justify-content-between">
                        
                    </div>
                    <br>
                    <br>
                    <div class="text-center user-info">
                        <a  target="_blank">
                            <img src="<?php echo e(asset($user->avatar)); ?>" style="width: 50%; padding: 10px;" alt="avatar">
                            <br><br>
                        </a>
                        <p class="text-uppercase"><?php echo e($user->name); ?> <?php echo e($user->apellido); ?></p>
                        <p class="text-uppercase"><?php echo e($user->rol); ?></p>

                    </div>
                    <br>
                    <br>
                    <br>
                </div>
            </div>
        </div>
        <div class="col-xl-8 col-lg-6 col-md-7 col-sm-12 ">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                <form action="<?php echo e(asset('usuarios/'.$user->id)); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <?php echo $__env->make('usuarios.form-edit',['titleform'=>'Actualizar usuario'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </form>
            </div>
        </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\empresasSST\resources\views/usuarios/show.blade.php ENDPATH**/ ?>